package com.cg.trainee.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.bean.Trainee;
import com.cg.trainee.exception.TraineeException;
import com.cg.trainee.service.ITraineeService;

@Controller
public class TraineeController {
	private static Logger log = Logger.getRootLogger();
	//PropertyConfigurator.configure
	
	@Autowired
	ITraineeService traineeService;

	@RequestMapping("showHomePage")
	public String showIndexPage() {
		return ("index");
	}

	@RequestMapping("add")
	public String showAddPage() {
		return ("addTrainee");
	}

	@RequestMapping(value = "addDetails", method = RequestMethod.POST)
	public ModelAndView addTrainee(@ModelAttribute("trainee") Trainee trainee,
			BindingResult result) {
		PropertyConfigurator.configure("resources/log4j.properties");
		ModelAndView mv = new ModelAndView();
		if (result.hasErrors()) {
			mv.setViewName("error");
			mv.addObject("message", result);
			log.error("Unable to add Trainee");
		} else {
			try {
				System.out.println(trainee.getTraineeName());
				int traineeId = traineeService.addTrainee(trainee);
				mv.setViewName("addSuccess");
				mv.addObject("traineeId", traineeId);
				log.info("Trainee"+trainee.getTraineeName()+" inserted successfully");
			} catch (TraineeException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
				log.error(e.getMessage());
			}
		}
		return mv;
	}

	@RequestMapping("delete")
	public String showDeletePage() {
		return ("deleteTrainee");
	}

	@RequestMapping("deleteTrainee")
	public ModelAndView deleteTrainee(@RequestParam("traineeId") int traineeId) {
		PropertyConfigurator.configure("resources/log4j.properties");
		ModelAndView mv = new ModelAndView();
		try {
			Trainee trainee = traineeService.deleteTrainee(traineeId);
			mv.setViewName("deleteTrainee");
			mv.addObject("trainee", trainee);
			log.info("Trainee"+trainee.getTraineeName()+" deleted successfully");
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
			log.error(e.getMessage());
		}
		return mv;
	}

	@RequestMapping("modify")
	public String showModifyPage() {
		return ("modifyTrainee");
	}

	@RequestMapping(value = "showModifyTrainee", method = RequestMethod.POST)
	public ModelAndView modifyTrainee(@RequestParam("traineeId") int traineeId) {
		ModelAndView mv = new ModelAndView();
		PropertyConfigurator.configure("resources/log4j.properties");
		try {
			Trainee trainee = traineeService.getTrainee(traineeId);
			mv.setViewName("modifyTrainee");
			mv.addObject("trainee", trainee);
			
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		return mv;
	}

	@RequestMapping(value = "modifyTrainee", method = RequestMethod.POST)
	public ModelAndView modifingTrainee(
			@ModelAttribute("trainee") Trainee trainee, BindingResult result) {
		PropertyConfigurator.configure("resources/log4j.properties");
		ModelAndView mv = new ModelAndView();
		if (result.hasErrors()) {
			mv.setViewName("error");
			mv.addObject("message", result);
		} else {
			try {
				boolean isUpdated = traineeService.updateTrainee(trainee);
				if (isUpdated) {
					mv.setViewName("updateSuccess");
					mv.addObject("trainee", trainee);
					log.info("Trainee salary modified successfully");
				}
			} catch (TraineeException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
				log.error(e.getMessage());
			}
		}
		return mv;
	}
	
	@RequestMapping("retrieve")
	public String retrieveTrainee(){
		return ("retrieveTrainee");
	}
	
	@RequestMapping(value = "showTrainee", method = RequestMethod.POST)
	public ModelAndView retrieve(@RequestParam("traineeId") int traineeId){
		PropertyConfigurator.configure("resources/log4j.properties");
		ModelAndView mv = new ModelAndView();
		try {
			Trainee trainee = traineeService.getTrainee(traineeId);
			mv.setViewName("retrieveTrainee");
			mv.addObject("trainee", trainee);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
			log.error("Fetching failed: "+e.getMessage());
		}
		return mv;
	}
	
	@RequestMapping("retrieveAll")
	public ModelAndView viewAllTrainee(){
		PropertyConfigurator.configure("resources/log4j.properties");
		ModelAndView mv = new ModelAndView();
		try {
			List<Trainee> list = traineeService.viewAllTrainee();
			mv.setViewName("allTrainee");
			mv.addObject("list", list);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
			log.error("Fetching failed: "+e.getMessage());
		}
		return mv;
	}
}
