package com.cg.trainee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.bean.Trainee;
import com.cg.trainee.dao.ITraineeDAO;
import com.cg.trainee.exception.TraineeException;

@Service
public class TraineeServiceImpl implements ITraineeService {

	@Autowired
	ITraineeDAO traineeDAO;

	@Override
	public int addTrainee(Trainee trainee) throws TraineeException {
		return traineeDAO.addTrainee(trainee);
	}

	@Override
	public Trainee deleteTrainee(int traineeId) throws TraineeException {
		return traineeDAO.deleteTrainee(traineeId);
	}

	@Override
	public Trainee getTrainee(int traineeId) throws TraineeException {
		return traineeDAO.getTrainee(traineeId);
	}

	@Override
	public boolean updateTrainee(Trainee trainee) throws TraineeException {
		return traineeDAO.updateTrainee(trainee);
	}

	@Override
	public List<Trainee> viewAllTrainee() throws TraineeException {
		return traineeDAO.viewAllTrainee();
	}

}
