package com.cg.trainee.service;

import java.util.List;

import com.cg.trainee.bean.Trainee;
import com.cg.trainee.exception.TraineeException;

public interface ITraineeService {
	public int addTrainee(Trainee trainee) throws TraineeException;
	public Trainee deleteTrainee(int traineeId) throws TraineeException;
	public Trainee getTrainee(int traineeId) throws TraineeException;
	public boolean updateTrainee(Trainee trainee) throws TraineeException;
	public List<Trainee> viewAllTrainee() throws TraineeException;
}
