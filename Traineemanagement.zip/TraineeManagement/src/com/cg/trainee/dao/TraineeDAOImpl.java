package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.trainee.bean.Trainee;
import com.cg.trainee.exception.TraineeException;

@Repository
@Transactional
public class TraineeDAOImpl implements ITraineeDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int addTrainee(Trainee trainee) throws TraineeException {
		int id = 0;
		try {
			entityManager.persist(trainee);
			entityManager.flush();
			id = trainee.getTraineeId();
		} catch (Exception e) {
			throw new TraineeException("Unable to persist " + e.getMessage());
		}
		return id;
	}

	@Override
	public Trainee deleteTrainee(int traineeId) throws TraineeException {
		Trainee trainee = null;
		try {
			trainee = entityManager.find(Trainee.class, traineeId);
			entityManager.remove(trainee);
		} catch (Exception e) {
			throw new TraineeException("Couldn't find Trainee for this id "
					+ traineeId + e.getMessage());
		}
		return trainee;
	}

	@Override
	public List<Trainee> viewAllTrainee() throws TraineeException {
		List<Trainee> traineeList = null;
		try {
			TypedQuery<Trainee> query = entityManager.createQuery(
					"FROM Trainee", Trainee.class);
			traineeList = query.getResultList();
		} catch (Exception e) {
			throw new TraineeException("Unable to insert " + e.getMessage());
		}
		return traineeList;
	}

	@Override
	public Trainee getTrainee(int traineeId) throws TraineeException {
		Trainee trainee = null;
		try {
			trainee = entityManager.find(Trainee.class, traineeId);
		} catch (Exception e) {
			throw new TraineeException("Couldn't find Trainee for this id "
					+ traineeId + e.getMessage());
		}
		return trainee;
	}

	@Override
	public boolean updateTrainee(Trainee trainee) throws TraineeException {
		boolean isUpdated = false;
		try {
			Trainee findTrainee = entityManager.find(Trainee.class, trainee.getTraineeId());
			findTrainee.setTraineeName(trainee.getTraineeName());
			findTrainee.setTraineeDomain(trainee.getTraineeDomain());
			findTrainee.setTraineeLocation(trainee.getTraineeLocation());
			entityManager.merge(findTrainee);
			isUpdated=true;
		} catch (Exception e) {
			throw new TraineeException("Couldn't find Trainee for this id "
					+ trainee.getTraineeId() + e.getMessage());
		}
		return isUpdated;
	}

}
